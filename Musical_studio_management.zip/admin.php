<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ad_name = $_POST["ad_name"];
    $password = $_POST["password"];

    // Query to check admin credentials
    $sql = "SELECT * FROM admin WHERE ad_name = '$ad_name' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Credentials matched, redirect to table.php
        header("Location: fill.html");
        exit();
    } else {
        echo "Invalid credentials. Please try again.";
    }
}

// Close the database connection
$conn->close();
?>
