<!DOCTYPE html>
<html>
<head>
    <title>Notown Musical Record</title>
    <style>
        /* ... your CSS styles ... */
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: bisque;
            margin: 0;
            padding: 0;
            background-size: cover;
            background-position: center;
        }
        
        header h1 {
      color: #fff;
      margin-right: 440px;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }
    
    nav {
      background-color: rgb(219, 115, 115);
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    nav img {
      height: 50px;
      margin-left: 20px;
    }
    
    nav ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
    }
    
    nav ul li {
      display: inline;
    }
    
    nav ul li a {
      color: #fff;
      padding: 8px;
      text-decoration:none;
      margin-left: 20px;
      font-size: larger;
    }

    nav ul li a:hover{
      background-color: rgb(232, 151, 151);
    }
        table {
            width: 60%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            border: 2px solid black;
            text-align: center;
        }

        th {
            background-color: rgb(238, 110, 110);
        }
        .h2{
            text-align: center;
        }

        ul {
            list-style-type: none; /* Remove bullet points */
            padding: 0;
        }

        .yo{
            margin-top:180px;
        }
        
    footer {
      background-color: rgb(238, 110, 110);
      color: #fff;
      padding: 10px;
      text-align: center;
      margin-top: 300px;
    }

    </style>
</head>
<body>
<header>
    <nav>
      <img src="image/music.png" alt="Notown Musical Record Logo">
      <h1>Notown Musical Record</h1>
      <ul>
        <li><a href="Home.html">Home</a></li>
        <li><a href="About.html">About Us</a></li>
        <li><a href="fetch.php">Music Details</a></li>
        <li><a href="admin.html">Admin</a></li>
        <li><a href="report.php">Report</a></li>
        <li><a href="contact.html">Contact Us</a></li>

      </ul>
    </nav>
</header>
<p class="yo"></p>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "records";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the musician ssn from the URL parameter
    if (isset($_GET['id'])) {
        $musician_ssn = $_GET['id'];

        // Fetch musician's details
        $sql_musician = "SELECT name FROM musician WHERE ssn = '$musician_ssn'";
        $result_musician = $conn->query($sql_musician);
        $musician_name = "";

        if ($result_musician->num_rows > 0) {
            $row_musician = $result_musician->fetch_assoc();
            $musician_name = $row_musician['name'];
        } else {
            echo "Musician not found.";
            $conn->close();
            exit;
        }

        // Fetch albums produced by the musician
        $sql_albums = "SELECT album_title, format FROM produces JOIN albums ON produces.album_id = albums.album_id WHERE produces.ssn = '$musician_ssn'";
        $result_albums = $conn->query($sql_albums);

        // Fetch songs performed by the musician
        $sql_songs = "SELECT song_title FROM performance JOIN song ON performance.song_id = song.song_id WHERE performance.ssn = '$musician_ssn'";
        $result_songs = $conn->query($sql_songs);

        // Fetch instruments played by the musician
        $sql_instruments = "SELECT instrument_name FROM musician_inst JOIN instrument ON musician_inst.instrument_id = instrument.instrument_id WHERE musician_inst.ssn = '$musician_ssn'";
        $result_instruments = $conn->query($sql_instruments);

        echo "<h2 class='h2'>Musician: $musician_name</h2>";

        if ($result_albums->num_rows > 0 || $result_songs->num_rows > 0 || $result_instruments->num_rows > 0) {
            echo "<table>
                    <tr>
                        <th>Album Title</th>
                        <th>Format</th>
                        <th>Songs Performed</th>
                        <th>Instruments Played</th>
                    </tr>";

            while ($row_album = $result_albums->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$row_album['album_title']."</td>";
                echo "<td>".$row_album['format']."</td>";

                if ($result_songs->num_rows > 0) {
                    echo "<td><ul>";
                    while ($row_song = $result_songs->fetch_assoc()) {
                        echo "<li>".$row_song['song_title']."</li>";
                    }
                    echo "</ul></td>";
                } else {
                    echo "<td>No songs performed.</td>";
                }

                if ($result_instruments->num_rows > 0) {
                    echo "<td>";
                    $instruments = array();
                    while ($row_instrument = $result_instruments->fetch_assoc()) {
                        $instruments[] = $row_instrument['instrument_name'];
                    }
                    echo implode(", ", $instruments);
                    echo "</td>";
                } else {
                    echo "<td>No instruments played.</td>";
                }
                

                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "<p>No albums, songs, or instruments found.</p>";
        }
    } else {
        echo "Musician ID not specified.";
    }

    // Close the database connection
    $conn->close();
    ?>
<footer>
  &copy; 2023 Notown Musical Record. All rights reserved.
</footer>

</body>
</html>
