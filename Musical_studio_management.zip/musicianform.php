<html>
<head>
  <title>Music Library Form</title>
  <style>
    /* CSS styles for the form */
    body {
      font-family: Arial, sans-serif;
      background-image: url('https://images.unsplash.com/photo-1598653222000-6b7b7a552625?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bXVzaWMlMjBzdHVkaW98ZW58MHx8MHx8fDA%3D&w=1000&q=80');
      margin: 0;
      padding: 0;
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }
    
    header h1 {
      color: #fff;
      margin-right: 410px;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }
    
    nav {
      background-color: rgb(219, 115, 115);
      padding: 2px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 5%;
    }
    
    nav img {
      height: 50px;
      margin-left: 20px;
    }
    
    nav ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
    }
    
    nav ul li {
      display: inline;
    }
    
    nav ul li a {
      color: #fff;
      padding: 10px;
      text-decoration:none;
      margin-right: 20px;
      font-size: larger;
    }

    nav ul li a:hover{
      background-color: rgb(232, 151, 151);
    }
    .form-container {
      max-width: 500px;
      margin: 0 auto;
      padding: 20px;
      background-color:rgba(242, 242, 242, 0.38);
      border-radius: 5px;
    }
    
    .form-container h2{
          margin-left: 150px;
        }

  .form-container label {
  display: block;
  margin-bottom: 10px;
  font-weight: bold; /* Add bold font weight to labels */
}

.form-container select,
.form-container input,
.form-container input[type="text"],
.form-container textarea {
  width: 99%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.form-container select {
  margin-bottom: 10px; /* Add margin to select elements */
}
    
    .form-container input[type="submit"] {
      background-color: rgb(232, 135, 135);
      width: 100%;
      color: white;
      padding: 15px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    textarea {
    
    width: 97%;
   
}
    
    .form-container input[type="submit"]:hover {
      background-color: rgb(241, 86, 86);
    }

    footer {
      background-color: rgb(238, 110, 110);
      color: #fff;
      padding: 10px;
      text-align: center;
      margin-top: 120px;
    }

  </style>
</head>
<body>
<body>
    <header>
        <nav>
          <img src="image/music.png" alt="Notown Musical Record Logo">
          <h1>Notown Musical Record</h1>
          <ul>
            <li><a href="Home.html">Home</a></li>
            <li><a href="About.html">About Us</a></li>
            <li><a href="fetch.php">Music Details</a></li>
            <li><a href="admin.html">Admin</a></li>
            <li><a href="report.php">Report</a></li>
            <li><a href="contact.html">Contact Us</a></li>
          </ul>
        </nav>
      </header>

<div class="form-container">
  <h2>Registration Form</h2>
    
  <form action="process_form.php" method="post">
      
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" placeholder="Enter musician's name" required><br><br>
    
    <label for="address">Address:</label>
    <textarea id="address" name="address" rows="4" placeholder="Enter musician's Address" required></textarea><br><br>
    
    <label for="phone_no">Phone no.:</label>
    <input type="text" id="phone_no" name="phone_no" placeholder="Enter musician's Phone no." required><br>
    
    
    <h3>Select Your Desired Instrument</h3>
    <label for="instrument_name1">Instrument Name 1:</label>
    <select id="instrument_name1" name="instrument_names[]"required>
      <option value="" disabled selected>Select an instrument</option>
      <?php
      // Retrieve instrument names from the instrument table in the database
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "records";

      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }

      $sql = "SELECT instrument_name FROM instrument";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $instrument_name = $row['instrument_name'];
          echo "<option value='$instrument_name'>$instrument_name</option>";
        }
      }
      $conn->close();
      ?>
    </select><br><br>
    
    <label for="instrument_name2">Instrument Name 2:</label>
<select id="instrument_name2" name="instrument_names[]" required>
  <option value="" disabled selected>Select an option</option> <!-- Add a default option -->
  <?php
  // Retrieve instrument names from the instrument table in the database
  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT instrument_name FROM instrument";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    echo "<option value='none'>None</option>"; // Add a "none" option
    while ($row = $result->fetch_assoc()) {
      $instrument_name = $row['instrument_name'];
      echo "<option value='$instrument_name'>$instrument_name</option>";
    }
  }
  $conn->close();
  ?>
</select><br><br>

<label for="instrument_name3">Instrument Name 3:</label>
<select id="instrument_name3" name="instrument_names[]" required>
  <option value="" disabled selected>Select an option</option> <!-- Add a default option -->
  <?php
  // Retrieve instrument names from the instrument table in the database
  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT instrument_name FROM instrument";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    echo "<option value='none'>None</option>"; // Add a "none" option
    while ($row = $result->fetch_assoc()) {
      $instrument_name = $row['instrument_name'];
      echo "<option value='$instrument_name'>$instrument_name</option>";
    }
  }
  $conn->close();
  ?>
</select><br>

     
    </select><br>
    
    <h4>Select The Album & The Song, You would like to Perform</h4>
    <label for="album_title">Album Title:</label>
    <select id="album_title" name="album_title" required>
      <option value="" disabled selected>Select an album</option>
      <?php
      // Retrieve album titles from the album table in the database
      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }

      $sql = "SELECT album_title FROM albums";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $album_title = $row['album_title'];
          echo "<option value='$album_title'>$album_title</option>";
        }
      }
      $conn->close();
      ?>
    </select>
    <br><br>
    
    <label for="song_id">Song:</label>
    <select id="song_id" name="song_id" required>
      <option value="" disabled selected>Select a song</option>
    </select><br>
    
    <script>
  // Fetch song titles associated with the selected album
  document.getElementById('album_title').addEventListener('change', function() {
    var albumTitle = this.value;
    var songIdSelect = document.getElementById('song_id');
    songIdSelect.innerHTML = '<option value="" disabled selected>Loading...</option>';
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          var songs = JSON.parse(xhr.responseText);
          songIdSelect.innerHTML = '<option value="" disabled selected>Select a song</option>';
          for (var i = 0; i < songs.length; i++) {
            var option = document.createElement('option');
            option.value = songs[i].song_id;
            option.text = songs[i].song_title;
            songIdSelect.appendChild(option);
          }

          // Add these lines to set the hidden input values
          document.getElementById('album_id').value = songs[0].album_id;
          document.getElementById('instrument_id1').value = songs[0].instrument_ids[0];
          document.getElementById('instrument_id2').value = songs[0].instrument_ids[1];
          document.getElementById('instrument_id3').value = songs[0].instrument_ids[2];

        } else {
          songIdSelect.innerHTML = '<option value="" disabled selected>Error loading songs</option>';
        }
      }
    };
    xhr.open('GET', 'get_songs.php?album_title=' + albumTitle, true);
    xhr.send();
  });
</script>


<input type="hidden" id="album_id" name="album_id">
<input type="hidden" id="instrument_id1" name="instrument_ids[]">
<input type="hidden" id="instrument_id2" name="instrument_ids[]">
<input type="hidden" id="instrument_id3" name="instrument_ids[]">

    <br><br>
    <input type="submit" value="Submit">
  </form>
  </div>
<footer>
  &copy; 2023 Notown Musical Record. All rights reserved.
</footer>
</body>
</html>