<!DOCTYPE html>
<html>
<head>
    <title>Notown Musical Record</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: bisque;
            margin: 0;
            padding: 0;
            background-size: cover;
            background-position: center;
        }
        
        header h1 {
      color: #fff;
      margin-right: 440px;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }
    
    nav {
      background-color: rgb(219, 115, 115);
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    nav img {
      height: 50px;
      margin-left: 20px;
    }
    
    nav ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
    }
    
    nav ul li {
      display: inline;
    }
    
    nav ul li a {
      color: #fff;
      padding: 8px;
      text-decoration:none;
      margin-left: 20px;
      font-size: larger;
    }

    nav ul li a:hover{
      background-color: rgb(232, 151, 151);
    }
        .tag {
            margin-top: 160px;
            margin-bottom: 30px;
            font-size:35px;
            font-style:bold;
        }
  
        table {
            width: 60%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            border: 2px solid black;
            text-align: center;
        }

        th {
            background-color: rgb(238, 110, 110);
        }

        button {
            padding: 5px 10px;
            cursor: pointer;
        }
        button:hover{
            background-color: #ccc;
        }

        
    footer {
      background-color: rgb(238, 110, 110);
      color: #fff;
      padding: 10px;
      text-align: center;
      margin-top: 400px;
    }

    </style>
</head>
<body>
<header>
    <nav>
      <img src="image/music.png" alt="Notown Musical Record Logo">
      <h1>Notown Musical Record</h1>
      <ul>
        <li><a href="Home.html">Home</a></li>
        <li><a href="About.html">About Us</a></li>
        <li><a href="fetch.php">Music Details</a></li>
        <li><a href="admin.html">Admin</a></li>
        <li><a href="report.php">Report</a></li>
        <li><a href="contact.html">Contact Us</a></li>
      </ul>
    </nav>
  </header>
    <p align="center" class="tag">Musician Details</p>
    <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "records";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch all records from the database
    $sql = "SELECT ssn,name FROM musician";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data as a table
        echo "<table border='1'>
                <tr>
                    <th>Sl. No.</th>
                    <th>Musician Name</th>
                    <th>Report</th>

                </tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>".$row['ssn']."</td>
                    <td>".$row['name']."</td>
                    <td>For More Information  <a href='details.php?id=".$row['ssn']."'><button>Click Here</button></a></td>
                  </tr>";
        }

        echo "</table>";
    } else {
        echo "No records found.";
    }
    // Close the database connection
    $conn->close();
    ?>
<footer>
  &copy; 2023 Notown Musical Record. All rights reserved.
</footer>

</body>
</html>
