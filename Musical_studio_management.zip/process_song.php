<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $song_title = $_POST["song_title"];
    $author = $_POST["author"];
    $album_id = $_POST["album_id"];

    // Generate the song ID (assuming it's auto-generated)
    $song_id = generateSongID();

    // Prepare and execute the SQL statement to insert the data into the database
    $sql = "INSERT INTO song (song_id, song_title, author, album_id) VALUES ('$song_id', '$song_title', '$author', $album_id)";
    if ($conn->query($sql) === TRUE) {
        echo "Data stored in the database successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Display the submitted data
    echo "<h2>Submitted Data</h2>";
    echo "Song ID: " . $song_id . "<br>";
    echo "Song Title: " . $song_title . "<br>";
    echo "Author: " . $author . "<br>";
    echo "Associated Album ID:  " . $album_id . "<br>";
}

function generateSongID() {
    // Implement your own logic to generate the album ID
    // Example: You can retrieve the last inserted ID from the database and increment it by 1
    // Modify this function based on your requirements
    global $conn;
    $sql = "SELECT MAX(song_id) AS max_id FROM song";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $max_id = $row['max_id'];
    return ($max_id !== null) ? ($max_id + 1) : 1;
}

// Close the database connection
$conn->close();
?>
