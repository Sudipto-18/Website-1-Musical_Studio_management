<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

// Get the selected album title from the AJAX request
$selectedAlbumTitle = $_GET['album_title'];

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and execute the SQL statement to retrieve the song titles associated with the selected album
$sql = "SELECT s.song_id, s.song_title FROM song s INNER JOIN albums a ON s.album_id = a.album_id WHERE a.album_title = '$selectedAlbumTitle'";
$result = $conn->query($sql);

// Store the retrieved song titles in an array
$songs = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $song = [
            'song_id' => $row['song_id'],
            'song_title' => $row['song_title']
        ];
        $songs[] = $song;
    }
}

// Close the database connection
$conn->close();

// Return the song titles as JSON
header('Content-Type: application/json');
echo json_encode($songs);
?>
