<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notown Musical Record</title>
    <style>
    /* Define the success animation */
    .success-animation {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        display: inline-block;
        padding: 20px;
        background-color: rgba(107, 191, 107, 0.9); /* Green color with some transparency */
        color: white;
        font-size: 50px; /* Adjust font size */
        border-radius: 10px;
        animation: fadeOut 5s ease-in-out forwards;
    }

    /* Define the error animation */
    .error-animation {
        background-color: rgba(231, 76, 60, 0.9); /* Red color with some transparency */
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        display: inline-block;
        padding: 20px;
        color: white;
        font-size: 50px; /* Adjust font size */
        border-radius: 10px;
        animation: fadeOut 5s ease-in-out forwards;
    }

    /* Keyframes for fading out animation */
    @keyframes fadeOut {
        0% {
            opacity: 1;
        }
        100% {
            opacity: 0;
        }
    }
</style>

</style>


</head>
<body>
<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "records";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function generateSSN() {
    // Implement your own logic to generate the SSN (e.g., retrieve it from a database or use an auto-incrementing value)
    // For simplicity, let's assume it's auto-generated and incrementing by 1 each time
    // You can modify this function based on your requirements
    // Example implementation:
    global $conn;
    $sql = "SELECT MAX(ssn) AS max_id FROM musician";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $max_id = $row['max_id'];
    return ($max_id !== null) ? ($max_id + 1) : 1;
}
function Validph($phone_no)
{
    return preg_match('/^[0-9]{10}$/',$phone_no);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = $_POST["name"];
    $address = $_POST["address"];
    $phone_no = $_POST["phone_no"];
    
    // Generate the SSN (assuming it's auto-generated)
    $ssn = generateSSN();
    $sqlCheckName = "SELECT ssn FROM musician WHERE name = '$name'";
    $resultCheckName = $conn->query($sqlCheckName);
    if ($resultCheckName->num_rows > 0) {
        // Display error message and do not proceed with insertion
        echo "<div class='error-animation'>Registration Failed &#10008;</div>";
        echo "Error: Musician Already Registered.";
    } else {
    if(Validph($phone_no))
    {
        // Prepare and execute the SQL statement to insert the musician data into the database
        $sql = "INSERT INTO musician (ssn, name, address, phone_no) VALUES ('$ssn', '$name', '$address', '$phone_no')";
        if ($conn->query($sql) === TRUE) {
            // Display success animation
            echo "<div class='success-animation'>Registration Successful &#10004;</div>";
        } else {
            echo "<div class='error-animation'>Registration Failed &#10008;</div>";
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        // Display the musician's information
        echo "<h2>Musician Information:</h2>";
        echo "<p>Musician SSN: $ssn</p>";
        echo "<p>Name: $name</p>";
        echo "<p>Address: $address</p>";
        echo "<p>Phone Number: $phone_no</p>";

         // Retrieve the form data for instruments, album, and song names
    $instrument_names = $_POST["instrument_names"];
    $album_title = $_POST["album_title"];
    $song_id = $_POST["song_id"];

    // Prepare and execute the SQL statement to insert the instrument data into the database
    $instrument_ids = array();
    foreach ($instrument_names as $index => $instrument_name) {
    if ($instrument_name !== 'none') { // Check if the instrument is not "none"
        $sql = "SELECT instrument_id FROM instrument WHERE instrument_name = '$instrument_name'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $instrument_ids[$index] = $row["instrument_id"];
        } else {
            // Handle error if instrument not found
            echo "Error: Instrument not found";
            exit;
        }
        echo "<p>Selected Instrument : $instrument_name</p>";
    }
}

    // Retrieve album ID from the database based on the selected album title
    $sql = "SELECT album_id FROM albums WHERE album_title = '$album_title'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $album_id = $row["album_id"];
        echo "<p>Selected Album : $album_title</p>";
    } else {
        // Handle error if album not found
        echo "<div class='error-animation'>Registration Failed &#10008;</div>";
        echo "Error: Album not found";
        exit;
    }

    
 // Retrieve song title and album ID from the database based on the selected song ID
$sql = "SELECT song_title, album_id FROM song WHERE song_id = '$song_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $song_title = $row["song_title"];
    $album_id = $row["album_id"];
    echo "<p>Selected Song : $song_title</p>";
} else {
    // Handle error if song not found
    echo "<div class='error-animation'>Registration Failed &#10008;</div>";
    echo "Error: Song not found";
    exit;
}

// Insert into the performance table
$sql = "INSERT INTO performance (ssn, song_id) VALUES ('$ssn','$song_id')";
if ($conn->query($sql) !== TRUE) {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Insert into the produce table
$sql = "INSERT INTO produces (ssn, album_id) VALUES ('$ssn','$album_id')";
if ($conn->query($sql) !== TRUE) {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Insert into the musician_inst table
foreach ($instrument_ids as $instrument_id) {
    $sql = "INSERT INTO musician_inst (ssn, instrument_id) VALUES ('$ssn','$instrument_id')";
    if ($conn->query($sql) !== TRUE) {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
  }
}
    else{
        echo "<div class='error-animation'>Registration Failed &#10008;</div>";
        echo 'Invalid Phone Number...Data Not stored';
    }
 }
}




// Close the database connection
$conn->close();
?>
    
</body>
</html>

